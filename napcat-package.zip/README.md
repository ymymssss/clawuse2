# NapCatQQ OpenClaw 消息渠道接入包

## 项目目标
通过 NapCatQQ 接入 QQ 群聊及私聊，创建 OpenClaw 消息渠道，支持完整 TG 功能。https://github.com/NapNeko/NapCatQQ

## 文件结构
```
napcat-package/
├── README.md                    # 本说明文件
├── docs/
│   ├── onebot-api.md            # OneBot API 研究报告
│   └── napcat-quickstart.md     # NapCat 快速开始指南
├── config/
│   ├── napcat.json              # NapCat 配置文件
│   └── onebot-client.json       # OneBot 客户端配置示例
├── scripts/
│   ├── run-napcat.sh            # NapCat 运行脚本
│   └── install-dependencies.sh  # 依赖安装脚本（需要 sudo）
└── napcat-data/                 # 运行时数据目录（需创建）
    └── config/
```

## 前置条件
- Linux 服务器（推荐）/ WSL2 / Docker
- 需要 sudo 权限安装系统依赖
- 或者使用 Docker 部署

## 快速开始

### 方法一：Docker 部署（推荐）

1. 启动 Docker daemon：
```bash
sudo dockerd &
```

2. 运行 NapCat Docker 容器：
```bash
docker run -d --name napcat \
  -p 3000:3000 \
  -p 5140:5140 \
  -v napcat-data:/app/config \
  nekoniko/napcat:latest
```

3. 验证服务：
```bash
curl http://localhost:3000/
```

### 方法二：WSL2/Linux 直接运行

1. 安装依赖：
```bash
sudo apt-get update
sudo apt-get install -y xvfb libnss3 libgbm1 libglib2.0-0t64 libatk1.0-0t64 libatspi2.0-0t64 libgtk-3-0t64 libasound2t64
```

2. 下载 NapCat AppImage：
```bash
cd ~/napcat
curl -L -o NapCat.AppImage "https://github.com/NapNeko/NapCatAppImageBuild/releases/download/v4.17.53/QQ-44343_NapCat-v4.17.53-amd64.AppImage"
chmod +x NapCat.AppImage
```

3. 运行：
```bash
./NapCat.AppImage --appimage-extract-and-run
```

### 方法三：Windows 一键部署

1. 下载：
https://github.com/NapNeko/NapCatQQ/releases/download/v4.17.49/NapCat.Shell.Windows.OneKey.zip

2. 解压运行 NapCatInstaller.exe

3. WebSocket 默认地址：`ws://127.0.0.1:5140/onebot`

## OneBot API 连接配置

### 反向 WebSocket 配置
```json
{
  "protocol": "ws",
  "host": "127.0.0.1",
  "port": 5140,
  "path": "/onebot",
  "token": "your-token-here"
}
```

### API 端点
- HTTP: http://127.0.0.1:3000/
- WebSocket: ws://127.0.0.1:5140/onebot

### 常用 API
| API | 说明 |
|-----|------|
| send_group_msg | 发送群消息 |
| send_private_msg | 发送私聊 |
| get_group_list | 获取群列表 |
| get_group_member_list | 获取群成员 |
| set_group_ban | 禁言成员 |
| set_group_kick | 踢出成员 |
| get_image | 获取图片 |
| get_record | 获取语音 |

## OpenClaw 消息渠道对接

待完成：创建 OpenClaw 适配器连接 OneBot API

### 预计步骤
1. 创建 napcat-channel 插件/适配器
2. 配置反向 WebSocket 连接
3. 实现消息收发、群管理功能
4. 测试并上线

## 已知问题

1. WSL2 运行 AppImage 可能遇到 V8 snapshot 错误，建议使用 Docker
2. 需要 sudo 权限安装依赖
3. Docker 需要 root 权限启动 daemon

## 相关链接
- NapCatQQ: https://github.com/NapNeko/NapCatQQ
- 文档: https://napneko.github.io/
- OneBot API: https://napcat.apifox.cn/

---

*Generated on 2026-04-04*
