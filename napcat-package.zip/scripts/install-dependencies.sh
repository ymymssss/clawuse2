#!/bin/bash
# NapCat 依赖安装脚本（需要 sudo）

echo "安装 NapCat 系统依赖..."

sudo apt-get update

sudo apt-get install -y \
    xvfb \
    libnss3 \
    libgbm1 \
    libglib2.0-0t64 \
    libatk1.0-0t64 \
    libatspi2.0-0t64 \
    libgtk-3-0t64 \
    libasound2t64 \
    curl \
    wget

echo "依赖安装完成！"
echo ""
echo "继续运行 NapCat："
echo "  cd ~/napcat"
echo "  ./NapCat.AppImage --appimage-extract-and-run"
