#!/bin/bash
# NapCat 运行脚本

# 配置
NAPCAT_DIR="$HOME/Napcat"
APPIMAGE_PATH="$HOME/napcat/NapCat.AppImage"
PORT=3000
WS_PORT=5140

# 检查 AppImage 是否存在
if [ ! -f "$APPIMAGE_PATH" ]; then
    echo "下载 NapCat AppImage..."
    mkdir -p ~/napcat
    cd ~/napcat
    curl -L -o NapCat.AppImage "https://github.com/NapNeko/NapCatAppImageBuild/releases/download/v4.17.53/QQ-44343_NapCat-v4.17.53-amd64.AppImage"
    chmod +x NapCat.AppImage
fi

# 运行 NapCat
echo "启动 NapCat..."
cd ~/napcat
xvfb-run -a ./NapCat.AppImage --appimage-extract-and-run &

# 等待服务启动
echo "等待服务启动..."
sleep 10

# 检查进程
if ps aux | grep -q "[q]q"; then
    echo "NapCat 已启动！"
    echo "HTTP: http://localhost:$PORT"
    echo "WebSocket: ws://localhost:$WS_PORT/onebot"
else
    echo "启动失败，请检查日志"
fi
