# NapCatQQ OneBot API 研究报告

## 1. 连接方式（均已支持 ✅）

| 方式 | 状态 |
|------|------|
| HTTP 接口调用 | ✅ |
| HTTP POST 事件上报 | ✅ |
| 正向 WebSocket | ✅ |
| 反向 WebSocket | ✅ |

**典型反向 WS 地址格式**：`ws://127.0.0.1:5140/onebot` 或 `ws://服务名:端口/ws`

---

## 2. 消息相关 API

| API | 说明 |
|-----|------|
| `send_msg` | 发送消息（通用） |
| `send_group_msg` | 发送群消息 |
| `send_private_msg` | 发送私聊消息 |
| `get_msg` | 获取消息 |
| `delete_msg` | 撤回消息 |

**消息段类型**：
- `text` / `image` / `record` / `video` / `file`
- `at` / `reply` / `markdown` / `xml` / `json`
- `music` / `location` / `poke` / `dice` / `rps`

**发送参数格式**：
```json
// 发送群消息
{ "group_id": "123456", "message": "hello" }

// 发送图片
{ "group_id": "123456", "message": [{"type": "image", "data": {"file": "file:///xxx.jpg"}}] }

// 发送私聊
{ "user_id": "123456", "message": "hello" }
```

---

## 3. 群管理 API

| API | 说明 |
|-----|------|
| `get_group_list` | 获取群列表 |
| `get_group_member_list` | 获取群成员列表 |
| `set_group_ban` | 群组单人禁言 |
| `set_group_whole_ban` | 群组全员禁言 |
| `set_group_kick` | 群组踢人 |
| `set_group_admin` | 设置管理员 |
| `set_group_card` | 设置群名片 |
| `set_group_name` | 设置群名 |
| `set_group_leave` | 退出群组 |

---

## 4. 文件操作 API

| API | 说明 |
|-----|------|
| `get_group_files` / `get_group_root_files` | 获取群文件列表 |
| `get_group_file_system_info` | 获取群文件系统信息 |
| `upload_group_file` | 上传群文件 |
| `get_record` | 获取语音 |
| `get_image` | 获取图片 |
| `get_group_file_url` | 获取群文件资源链接 |

---

## 5. 重要注意事项

1. **ID 类型**：v4.8.115+ 版本推荐 `group_id`/`user_id` 使用**字符串类型**，避免大整数问题
2. **Token**：WebSocket 连接通常需要配置 Token 认证
3. **文档**：完整 API 文档见 [napcat.apifox.cn](https://napcat.apifox.cn/)
4. **流式 API**：新版本支持 Stream API 用于大文件传输

---

## 6. 对 OpenClaw 的价值

NapCatQQ 完整实现了 OneBot 11 协议，**非常适合作为 OpenClaw 的 QQ 消息渠道**：
- 消息收发完整支持（文字/图片/语音/文件）
- 群管理能力充足
- 支持反向 WS 接入，部署灵活
