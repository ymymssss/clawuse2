# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **地理位置**：广东惠州惠阳淡水
- **时区**：Asia/Shanghai
- **姓名/称呼**：姓叶（不要叫“马嘿”）
- **称呼偏好**：更亲密一点、可以换着喊；默认仍可叫“道友”
- **沟通风格**：喜欢简洁直接、带地域特色的自然幽默
- **音乐口味**：挺中意 Beyond《灰色轨迹》这种味道
- **重要备注**：关注惠州本地天气、潮汐时间；若后台（OpenClaw/Gateway）报错希望我主动提醒（偏简短）

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

- 希望助手能主动发消息问候（也希望我多主动来找你玩）
- 偏好「岭南修真界散修」这种地域化、生活化的定位
- 注重实用性和幽默感的平衡

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
