#!/usr/bin/env python3
"""Shared safety helpers for web-pilot scripts.

Goals:
- Prevent SSRF / local network access by default.
- Enforce http/https URLs.
- Constrain file outputs to safe directories by default.
- Standardize JSON error output.

This file is intentionally dependency-light.
"""

from __future__ import annotations

import ipaddress
import json
import os
import re
import socket
import urllib.parse
from dataclasses import dataclass
from typing import Iterable, Optional


DEFAULT_MAX_BYTES = 50 * 1024 * 1024  # 50MB


def json_error(message: str, hint: str | None = None, **extra) -> str:
    obj = {"error": message}
    if hint:
        obj["hint"] = hint
    obj.update(extra)
    return json.dumps(obj, indent=2, ensure_ascii=False)


def _is_localhost_name(host: str) -> bool:
    h = host.strip().lower().rstrip(".")
    return h in {"localhost", "localhost.localdomain"} or h.endswith(".local")


def _iter_resolved_ips(host: str) -> Iterable[str]:
    # getaddrinfo can throw; let callers handle.
    infos = socket.getaddrinfo(host, None)
    for family, _, _, _, sockaddr in infos:
        if family == socket.AF_INET:
            yield sockaddr[0]
        elif family == socket.AF_INET6:
            yield sockaddr[0]


def is_private_ip(ip_str: str) -> bool:
    ip = ipaddress.ip_address(ip_str)
    return (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
    )


@dataclass
class UrlCheckResult:
    ok: bool
    url: str | None = None
    reason: str | None = None
    host: str | None = None
    resolved_ips: list[str] | None = None


def validate_url(
    url: str,
    *,
    allow_private: bool = False,
    allow_http: bool = True,
    allowed_schemes: tuple[str, ...] = ("http", "https"),
) -> UrlCheckResult:
    if not url or not isinstance(url, str):
        return UrlCheckResult(False, reason="URL is empty")

    url = url.strip()
    try:
        u = urllib.parse.urlparse(url)
    except Exception:
        return UrlCheckResult(False, reason="URL parse failed")

    scheme = (u.scheme or "").lower()
    if scheme not in allowed_schemes:
        return UrlCheckResult(False, reason=f"Disallowed URL scheme: {scheme}. Only http/https are allowed.")

    if scheme == "http" and not allow_http:
        return UrlCheckResult(False, reason="HTTP is disabled by policy")

    host = u.hostname
    if not host:
        return UrlCheckResult(False, reason="URL missing host")

    # Block obvious local names.
    if _is_localhost_name(host) and not allow_private:
        return UrlCheckResult(False, reason="Private/localhost targets are blocked by default")

    resolved: list[str] = []

    # If host is already an IP literal, check it.
    try:
        ip_lit = ipaddress.ip_address(host)
        resolved = [str(ip_lit)]
    except ValueError:
        # Resolve DNS and check the resulting IPs.
        try:
            resolved = list(dict.fromkeys(_iter_resolved_ips(host)))
        except Exception:
            # If DNS resolution fails, still allow public domain by name.
            # This keeps behavior usable in restricted DNS environments.
            resolved = []

    if not allow_private:
        # Block if any resolved IP is private.
        for ip_str in resolved:
            try:
                if is_private_ip(ip_str):
                    return UrlCheckResult(
                        False,
                        reason="Private/loopback/link-local targets are blocked by default (SSRF protection)",
                        host=host,
                        resolved_ips=resolved,
                    )
            except Exception:
                # If parsing fails, be conservative.
                return UrlCheckResult(False, reason="Failed to validate resolved IP")

        # Also block some host patterns without DNS.
        if host.strip().lower() in {"127.0.0.1", "::1"}:
            return UrlCheckResult(False, reason="Localhost is blocked by default")

    return UrlCheckResult(True, url=url, host=host, resolved_ips=resolved)


def validate_proxy_url(proxy: str) -> tuple[bool, str | None]:
    if not proxy:
        return True, None
    try:
        u = urllib.parse.urlparse(proxy)
    except Exception:
        return False, "Proxy URL parse failed"
    if (u.scheme or "").lower() not in {"http", "https"}:
        return False, "Proxy scheme must be http or https"
    if not u.hostname:
        return False, "Proxy URL missing host"
    return True, None


def _norm(p: str) -> str:
    return os.path.abspath(os.path.expanduser(p))


def validate_output_path(
    path: str,
    *,
    allow_unsafe: bool = False,
    allowed_roots: Optional[list[str]] = None,
) -> tuple[bool, str | None, str | None]:
    """Validate that an output path is within allowed roots.

    Returns: (ok, abs_path, reason)
    """

    if not path:
        return False, None, "Output path is empty"

    ap = _norm(path)

    if allow_unsafe:
        return True, ap, None

    roots = allowed_roots or ["/tmp", os.getcwd()]
    roots_abs = [_norm(r) for r in roots]

    # Ensure path is within any root.
    for r in roots_abs:
        # commonpath raises if drives differ; on linux it's ok.
        try:
            if os.path.commonpath([ap, r]) == r:
                return True, ap, None
        except Exception:
            pass

    return False, ap, f"Output path must be under one of: {', '.join(roots_abs)} (use --unsafe-path to override)"


def sanitize_filename(name: str) -> str:
    # Keep it simple: strip separators and control chars.
    name = name.strip().replace("\x00", "")
    name = re.sub(r"[\\/]+", "_", name)
    name = re.sub(r"\s+", " ", name).strip()
    if not name:
        return "download.bin"
    # Prevent hidden dotfiles by default.
    if name.startswith("."):
        name = "download" + name
    return name
