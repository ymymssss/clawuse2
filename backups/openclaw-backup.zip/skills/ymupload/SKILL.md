# ymupload - 上传文件到 GitHub

上传本地文件/文件夹到 GitHub 仓库 (ymymssss/clawuse2)。

## 使用场景
- 需要分享文件链接给用户时
- 上传图片/文档到 GitHub 并生成 raw 链接
- 需要生成可访问的外部链接

## 命令格式

```bash
ymupload <文件路径> [目标子目录] [提交信息]
```

## 示例

### 上传图片
```bash
ymupload ./ai-cover-small.jpg uploads/ai-article "upload: AI article cover"
```

### 上传文件夹
```bash
ymupload ./build/ uploads/myapp "upload: build files"
```

### 上传文件（自动生成子目录）
```bash
ymupload ./notes.txt
```
自动存入: `uploads/<agent>/<YYYY-MM-DD>/notes.txt`

## 输出结果
成功后返回：
- GitHub Raw 链接格式：`https://raw.githubusercontent.com/ymymssss/clawuse2/main/uploads/ai-article/ai-cover-small.jpg`

## 注意事项
- 脚本位置：`/data/data/com.termux/files/home/.openclaw/workspace/scripts/ymupload.sh`
- 目标仓库：`git@github-clawuse2:ymymssss/clawuse2.git`
- 子目录前缀：`uploads/`
- 拒绝上传：*.key, *.pem, *.p12, *.env 等敏感文件
